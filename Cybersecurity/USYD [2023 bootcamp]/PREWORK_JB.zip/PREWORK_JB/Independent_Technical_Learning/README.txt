Part 1
An option is a named parameter that can be passed to a command. The convention is to  prefix the option name with two Hyphens (--)
There are also other parts of the command, such as Arugments.

Part 2
I want to learn a lot about hacking and security. But as I have a lot of experience within sofrware and the tools that many use. But I want to be able to have the mindset of hacking, so that I can also implement it into my work as a software engineer. 
I'm most exited with this, to learn how to more so become an security analyst. 
